#!/bin/bash

# YTTL PyPI Upload Script
# Make sure you have accounts on PyPI and TestPyPI

echo "🚀 Starting YTTL PyPI upload process..."

# Step 1: Install required tools
echo "📦 Installing build tools..."
pip install --upgrade pip build twine

# Step 2: Clean previous builds
echo "🧹 Cleaning previous builds..."
rm -rf dist/ build/ *.egg-info/

# Step 3: Build the package
echo "🔨 Building package..."
python -m build

# Step 4: Check the package
echo "🔍 Checking package..."
twine check dist/*

if [ $? -ne 0 ]; then
    echo "❌ Package check failed. Please fix the issues and try again."
    exit 1
fi

echo "✅ Package check passed!"

# Step 5: Upload to TestPyPI (optional but recommended)
echo "🧪 Uploading to TestPyPI..."
echo "You'll be prompted for your TestPyPI credentials."
twine upload --repository testpypi dist/*

if [ $? -eq 0 ]; then
    echo "✅ TestPyPI upload successful!"
    echo "🔗 Check your package at: https://test.pypi.org/project/yttl/"
    echo ""
    echo "Test installation with:"
    echo "pip install --index-url https://test.pypi.org/simple/ --extra-index-url https://pypi.org/simple/ yttl"
    echo ""
    read -p "Press Enter to continue with production PyPI upload, or Ctrl+C to stop..."
else
    echo "❌ TestPyPI upload failed. Please check your credentials and try again."
    exit 1
fi

# Step 6: Upload to production PyPI
echo "🚀 Uploading to production PyPI..."
echo "You'll be prompted for your PyPI credentials."
twine upload dist/*

if [ $? -eq 0 ]; then
    echo "🎉 Success! YTTL has been uploaded to PyPI!"
    echo "🔗 Check your package at: https://pypi.org/project/yttl/"
    echo ""
    echo "Users can now install with:"
    echo "pip install yttl"
    echo ""
    echo "Test the installation:"
    echo "yttl --help"
else
    echo "❌ PyPI upload failed. Please check your credentials and try again."
    exit 1
fi