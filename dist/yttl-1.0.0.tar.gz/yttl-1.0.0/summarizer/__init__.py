# SPDX-License-Identifier: Apache-2.0

def cli_main():
    from .cli import main
    main()

def extension_main():
    from .extension import main
    main()
