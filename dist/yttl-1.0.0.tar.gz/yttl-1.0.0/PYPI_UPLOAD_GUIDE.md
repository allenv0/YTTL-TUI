# PyPI Upload Guide for YTTL

## Prerequisites

1. **Create PyPI Account**
   - Go to https://pypi.org/account/register/
   - Create an account and verify your email

2. **Create TestPyPI Account** (recommended for testing)
   - Go to https://test.pypi.org/account/register/
   - Create an account for testing uploads

3. **Install Required Tools**
   ```bash
   pip install --upgrade pip build twine
   ```

## Step-by-Step Upload Process

### Step 1: Clean Previous Builds
```bash
# Remove any previous build artifacts
rm -rf dist/ build/ *.egg-info/
```

### Step 2: Build the Package
```bash
# Build the package
python -m build
```

This will create:
- `dist/yttl-1.0.0.tar.gz` (source distribution)
- `dist/yttl-1.0.0-py3-none-any.whl` (wheel distribution)

### Step 3: Check the Package
```bash
# Check the package for common issues
twine check dist/*
```

### Step 4: Test Upload to TestPyPI (Recommended)
```bash
# Upload to TestPyPI first
twine upload --repository testpypi dist/*
```

You'll be prompted for:
- Username: Your TestPyPI username
- Password: Your TestPyPI password

### Step 5: Test Installation from TestPyPI
```bash
# Test install from TestPyPI
pip install --index-url https://test.pypi.org/simple/ --extra-index-url https://pypi.org/simple/ yttl

# Test the command
yttl --help
```

### Step 6: Upload to Production PyPI
```bash
# Upload to production PyPI
twine upload dist/*
```

You'll be prompted for:
- Username: Your PyPI username  
- Password: Your PyPI password

### Step 7: Verify Installation
```bash
# Install from PyPI
pip install yttl

# Test the installation
yttl --help
```

## Using API Tokens (Recommended)

Instead of username/password, use API tokens for better security:

### Create API Tokens
1. **PyPI**: Go to https://pypi.org/manage/account/token/
2. **TestPyPI**: Go to https://test.pypi.org/manage/account/token/

### Configure .pypirc
Create `~/.pypirc`:
```ini
[distutils]
index-servers =
    pypi
    testpypi

[pypi]
username = __token__
password = pypi-your-api-token-here

[testpypi]
repository = https://test.pypi.org/legacy/
username = __token__
password = pypi-your-testpypi-token-here
```

### Upload with Tokens
```bash
# Upload to TestPyPI
twine upload --repository testpypi dist/*

# Upload to PyPI
twine upload dist/*
```

## Troubleshooting

### Common Issues

**Package Name Already Exists**
- Choose a different name in `pyproject.toml`
- Check availability at https://pypi.org/project/your-package-name/

**Build Fails**
```bash
# Check for missing files
python -m build --verbose

# Ensure all dependencies are listed in pyproject.toml
```

**Upload Fails**
```bash
# Check package format
twine check dist/*

# Verify credentials
twine upload --repository testpypi dist/* --verbose
```

**Import Errors After Install**
- Ensure package structure is correct
- Check that all Python files have proper imports
- Verify entry points in pyproject.toml

### Version Updates

For future updates:
1. Update version in `pyproject.toml`
2. Clean and rebuild: `rm -rf dist/ && python -m build`
3. Upload new version: `twine upload dist/*`

## Package Information

- **Package Name**: yttl
- **Version**: 1.0.0
- **Command**: `yttl` (primary), `summarize` (legacy)
- **Description**: YTTL (YouTube To Text and LLM) - AI-powered video summarization tool

## Post-Upload

After successful upload:
1. Check your package page: https://pypi.org/project/yttl/
2. Update documentation with installation instructions
3. Test installation on different systems
4. Consider setting up automated releases with GitHub Actions

## Security Notes

- Never commit API tokens to version control
- Use environment variables for sensitive data
- Consider using GitHub Actions for automated releases
- Regularly rotate API tokens